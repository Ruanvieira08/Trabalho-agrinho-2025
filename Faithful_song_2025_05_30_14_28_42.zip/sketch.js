function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let xVeiculo = 0;
let indoParaCidade = true;
let dia = true;
let showTratorMsg = false;
let showPredioMsg = false;

function setup() {
  createCanvas(800, 400);
  let botaoDiaNoite = createButton("Alternar Dia/Noite");
  botaoDiaNoite.position(10, 10);
  botaoDiaNoite.mousePressed(toggleDiaNoite);
}

function draw() {
  if (dia) {
    background(135, 206, 235); // céu azul
  } else {
    background(20, 24, 82); // céu noturno
  }

  desenhaCampo();
  desenhaCidade();
  desenhaEstrada();
  desenhaVeiculo();
  desenhaPersonagens();
  
  moverVeiculo();
  mostrarMensagem();

  if (showTratorMsg) {
    fill(255);
    rect(100, 100, 160, 60);
    fill(0);
    text("O trator ajuda na colheita!", 110, 130);
  }

  if (showPredioMsg) {
    fill(255);
    rect(550, 100, 160, 60);
    fill(0);
    text("Os prédios abrigam serviços e comércios!", 560, 130);
  }
}

function desenhaCampo() {
  fill(34, 139, 34); 
  rect(0, 200, 400, 200);
  
  // Trator
  fill(139, 69, 19);
  rect(100, 150, 30, 50);
  
  // Sol ou lua
  if (dia) {
    fill(255, 215, 0);
    ellipse(50, 70, 50, 50);
  } else {
    fill(255, 255, 200);
    ellipse(50, 70, 40, 40);
  }

  fill(0);
  textSize(16);
  text("Campo", 150, 220);
}

function desenhaCidade() {
  fill(200);
  rect(400, 100, 400, 300);

  for (let i = 420; i < 800; i += 60) {
    fill(100);
    rect(i, 150, 40, 150);
    if (!dia) {
      fill(255, 255, 100);
      rect(i + 10, 160, 20, 30); // janelas acesas
    }
  }

  fill(0);
  text("Cidade", 600, 220);
}

function desenhaEstrada() {
  fill(50);
  rect(0, 300, 800, 60);
  for (let i = 0; i < width; i += 40) {
    fill(255);
    rect(i, 328, 20, 4);
  }
}

function desenhaVeiculo() {
  fill(255, 0, 0);
  rect(xVeiculo, 310, 60, 30);
  fill(0);
  ellipse(xVeiculo + 10, 340, 15, 15);
  ellipse(xVeiculo + 50, 340, 15, 15);
}

function moverVeiculo() {
  if (indoParaCidade) {
    xVeiculo += 2;
    if (xVeiculo > width) {
      indoParaCidade = false;
    }
  } else {
    xVeiculo -= 2;
    if (xVeiculo < -60) {
      indoParaCidade = true;
    }
  }
}

function mostrarMensagem() {
  fill(0);
  textSize(14);
  textAlign(CENTER);
  if (indoParaCidade && xVeiculo > 200 && xVeiculo < 400) {
    text("Levando alimentos do campo para a cidade!", width / 2, 50);
  } else if (!indoParaCidade && xVeiculo > 400 && xVeiculo < 600) {
    text("Levando tecnologia e serviços para o campo!", width / 2, 50);
  }
}

function toggleDiaNoite() {
  dia = !dia;
}

function mousePressed() {
  // Se clicar no trator
  if (mouseX > 100 && mouseX < 130 && mouseY > 150 && mouseY < 200) {
    showTratorMsg = !showTratorMsg;
    showPredioMsg = false;
  }

  // Se clicar em um dos prédios
  if (mouseX > 420 && mouseX < 780 && mouseY > 150 && mouseY < 300) {
    showPredioMsg = !showPredioMsg;
    showTratorMsg = false;
  }
}

function desenhaPersonagens() {
  // Pessoa no campo
  fill(255, 220, 180);
  ellipse(250, 260, 20, 20); // cabeça
  line(250, 270, 250, 300); // corpo
  line(240, 290, 260, 290); // braços
  line(250, 300, 240, 320); // perna 1
  line(250, 300, 260, 320); // perna 2

  // Pessoa na cidade
  fill(255, 220, 180);
  ellipse(650, 260, 20, 20);
  line(650, 270, 650, 300);
  line(640, 290, 660, 290);
  line(650, 300, 640, 320);
  line(650, 300, 660, 320);
}
